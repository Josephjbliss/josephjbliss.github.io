# ArtNewFaux

## Build a homepage for ArtNewFaux, an Art blog.

# Mark-up and Layout the Homepage

## Write the HTML and CSS to finish the Homepage.

When you've finished:

- Zip `index.html` and `index.css` to a file named `index.zip`
- Upload `index.zip`
<br></br> 

### The Problem

You are building a new homepage for ArtNewFaux, an Art Blog, which will include a featured image with caption, top stories, blog roll with article excertps and photos, and category navigation. 

![Homepage](assets/layout.png)

### What to Code

Add additional markup to `index.html` where indicated: 

    <!-- Add Markup Here -->

and styles to `css/index.css` where indicated:

    /* Add Styles Here */

to match the provided design.

All necessary text is in the html document already.

All necessary images can be found in `images/`.

Annotated design mockups are provided for you and will outline all of the styles on the page necessary to complete the task. Annotated design mockups can be found in `mockups/` and include:

- `600.png`
- `1280.png`

Strive for pixel perfection.

*DO NOT* alter the `<section>` tags or their id's. 

When you've finished:

- Zip `index.html` and `index.css` to a file named `index.zip`
- Upload `index.zip`
<br></br>

---

### Grading

You will be graded on:

- Function (75%): The extent to which you match the provided design.
- Efficiency (20%): The maintainability of your code, which is impacted by its size and the computational effort required to run it.
- Consistency (5%): How well your code adheres to the style guide below. 

---

### Style guide

Use only lowercase characters (for elements, attributes, selectors, properties, etc.)

HTML:

- Begin block objects on their own line.
- Do not skip lines.
- Indent child elements (two spaces).
- Use double quotation marks - ".

CSS:

- Separate words in ID and Class names by a hyphen.
- Indent declarations, as well as rules within media queries (two spaces).
- Use single quotation marks - '.
- Semicolons: always use.
- Separate rules by new lines.

If you're unsure about a particular situation, refer to the Google HTML/CSS Style Guide at [https://google.github.io/styleguide/htmlcssguide.xml](https://google.github.io/styleguide/htmlcssguide.xml)
