$(function() {
  'use strict';

  var threshold1 = $('#slide1').offset().top + $('#slide1').height() / 2;
  var threshold2 = $('#slide2').offset().top + $('#slide2').height() / 2;
  var threshold3 = $('#slide3').offset().top + $('#slide3').height() / 2;
  var threshold4 = $('#slide4').offset().top + $('#slide4').height() / 2;

  var resetThresholds = function() {
    threshold1 = $('#slide1').offset().top + $('#slide1').height() / 2;
    threshold2 = $('#slide2').offset().top + $('#slide2').height() / 2;
    threshold3 = $('#slide3').offset().top + $('#slide3').height() / 2;
    threshold4 = $('#slide4').offset().top + $('#slide4').height() / 2;
  };

  var resizeTimer;

  //'Debounce' resize event
  $(window).on('resize', function() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {
      resetThresholds();
      $('body').scrollTop(0);
    }, 100);
  });

  $('aside a').on('click', function(e) {
    e.preventDefault();
    var target = $($(this).attr('href'));
    $('body').stop().animate({ scrollTop: Math.ceil(target.offset().top) }, 500);
  });

  var checkDots = function() {
    if ($(window).scrollTop() < threshold1) {
      selectDot(0);
    } else if ($(window).scrollTop() < threshold2) {
      selectDot(1);
    } else if ($(window).scrollTop() < threshold3) {
      selectDot(2);
    } else if ($(window).scrollTop() < threshold4) {
      selectDot(3);
    }
  };

  var selectDot = function(i) {
    $('aside a.fa-circle').removeClass('fa-circle').addClass('fa-circle-o');
    $('aside a').eq(i).removeClass('fa-circle-o').addClass('fa-circle');
  }

  $(window).on('scroll', function() {
    checkDots();
  });

});
