$(function() {
  'use strict';

  var jsonURL = 'http://credentials-api.generalassemb.ly/78a475a4-20e2-4905-a7c7-8a10ec43fa27';

  $(document).on('ready', function() {
    $('#blog nav a:first-child').trigger('click');
  });

  $('#blog nav a').on('click', function(evt) {
    evt.preventDefault();
    $('#blog nav a').removeClass('current');
    $(this).addClass('current');
    var category = $(this).data('category');
    var newURL = jsonURL;

    if (category != 'recent') {
      newURL = jsonURL + '?category=' + category;
    }

    $('#articles article').remove();
    $('#blog').addClass('loading');
    $.getJSON(newURL, function(data) {
      $.each(data.articles, function(key, val) {

        var article = $('<article/>');
        article.addClass(val.category);
        article.append($('<h4/>').html(val.title));
        article.append($('<h5/>').html(val.category).append($('<span/>').addClass('date').html(val.date)));
        article.append($('<figure/>').append($('<img/>').attr('src', val.image).attr('alt', val.credit)).append($('<figcaption/>').html(val.credit)));
        article.append($('<p/>').html(val.blurb));
        article.append($('<p/>').addClass('read-more').append($('<a/>').html('read more ...').attr('href', val.permalink)));
        $('#articles').append(article);
        $('#blog').removeClass('loading');
      });
    });
  });
});
