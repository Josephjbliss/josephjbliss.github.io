$("header").on("click", function(){
  $(this).next().slideToggle(500);
  $(this).find("span").toggleClass("fa-chevron-down");
  $(this).find("span").toggleClass("fa-minus");
});