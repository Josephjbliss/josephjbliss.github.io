$(document).ready(function() {
  $("a").on("click", function() { 
    var color = $(this).attr("data-color");
    $("p").css("color", color);
    $("header").css("background-color", color);
    $("a").css("background-color", color);
  });
  
  // $("p").on("mouseenter", function(){
  //   $(this).css("color", "black");
  // });
});