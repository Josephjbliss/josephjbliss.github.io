$(document).ready(function(){
  $("a").click(function() {
    $("p").css("color", $(this).data("color"));
    $("a").css("background-color", $(this).data("color"));
    $("header").css("background-color", $(this).data("color"));
  });
});