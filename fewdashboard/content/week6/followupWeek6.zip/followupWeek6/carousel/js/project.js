$("nav a").click(function(){
  $("nav a.current").removeClass("current");
  $(this).addClass("current");
  var whichSlide = $(this).index();
  $("div.current").removeClass("current");
  $("div").eq(whichSlide).addClass("current");
});