document.getElementById("convert").onclick = convert;

function convert() {
  var temp = document.getElementById("temptoconvert").value;
  var newTemp = (temp - 32) * 5 / 9;
  document.getElementById("solution").innerHTML = newTemp + "&deg; C";
}

document.getElementById("convertF").onclick = convertF;

function convertF() {
  var tempF = document.getElementById("temptoconvertF").value;
  var newTempF = (tempF * 9 / 5) + 32;
  document.getElementById("solutionF").innerHTML = newTempF + "&deg; F";
}
