$(".thumb").on("click", function(){ 
  // Replace src attribute of the #bigmage with the src attribute of the thumbnail I clicked on
  var image = $(this).attr("src");
  
  $("#bigimage").hide();
  $("#bigimage").attr("src", image);
  $("#bigimage").fadeIn(500);

  // As a single line:
  // $("#bigimage").attr("src", $(this).attr("src"));
});