$(".thumb").click(function() {
  var imgSrc = $(this).attr("src");
  $("#bigimage").fadeOut(1000, function() {
    $("#bigimage").attr("src", imgSrc);
    $("#bigimage").fadeIn(1000);
  });
});