$(document).ready(function(){
  $("div").mouseenter(function(){
    $(this).css("background-color", "red").html("New Text").animate({
      height: 200, 
      "width": "100%", 
      fontSize: "40px"
    }, 2000);
  });

  $("div").click(function(){
    // .stop() will stop the currently running effect, so this will allow it to delete even if the .animate() above isn't finished. 
    $(this).stop().fadeOut(400, function(){
      $(this).remove();
    });
  });
});