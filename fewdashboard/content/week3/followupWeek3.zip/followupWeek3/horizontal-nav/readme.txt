Navigation
background-color: black;

Navigation Anchors
color: #cccccc

Navigation Hover
color: #ffffff
background-color: #ff7401
