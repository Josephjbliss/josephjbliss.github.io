var someSum = 2 + 3;
var nameMessage = "My name is Joe";
var students = ["Luisa", "Kiara", "Dana", "Gabe", "Tanner"];

var student1 = {
 name: "Luisa",
 seat: "2c",
 grade: 98,
 email: "luisaisawesome@aol.com",
 address: { 
    street: "100 Fake Street", 
    city: "New York",
    state: "NY",
    zip: 10011
  },
  printStudent: function() { 
    document.write("<div>");
    document.write(this.name, "<br>", this.seat, "<br>", this.grade, "<br>", this.email);
    document.write("</div>");
    alert("This is also being called here!");
  }
}

var studentRoster = [{
 name: "Luisa",
 seat: "2c",
 grade: 98,
 email: "luisaisawesome@aol.com"
}, {
 name: "Kiara",
 seat: "2f",
 grade: 98,
 email: "kiara@aol.com" 
}, {
 name: "Dana",
 seat: "2e",
 grade: 98,
 email: "dana@aol.com" 
}, {
 name: "Gabe",
 seat: "3b",
 grade: 98,
 email: "luisaisawesome@aol.com" 
}]

function writeDiv(text) {
  document.write("<div>");
  document.write(text);
  document.write("</div>");
}

document.write('<div>');
document.write(12 * 4);
document.write("<br>");
document.write(12 * 4);
document.write('</div>');

writeDiv("It's been \"purchased\"");
writeDiv(5 * 23);
writeDiv(4 - 2);
writeDiv(42 / 6);
writeDiv(7 + 8);
writeDiv(nameMessage);
writeDiv("IT'S A TRAP!");

// Re-assign Variable Value
nameMessage = "My name is now Steve";
writeDiv(nameMessage);

writeDiv(students[2]);

writeDiv(student1.address.street);

student1.printStudent();

debugger;

document.body.className = "new-class";

alert(document.body.className);

// studentRoster.forEach(function(student) {
//   document.write("<div class=\"student\">");
//   document.write("Name:");
//   document.write(student.name);
//   document.write("<br>");
//   document.write("Email:");
//   document.write(student.email);
//   document.write("<br>");
//   document.write("Seat:");
//   document.write(student.seat);
//   document.write("<br>");
//   document.write("Grade:");
//   document.write(student.grade);
//   document.write("</div>");
// });

