

// Blank-out the inputs on focus
document.getElementById("name").onfocus = focusName;

function focusName() {
  document.getElementById("name").value = "";
}

document.getElementById("grade").onfocus = focusGrade;

function focusGrade() {
  document.getElementById("grade").value = "";
}
