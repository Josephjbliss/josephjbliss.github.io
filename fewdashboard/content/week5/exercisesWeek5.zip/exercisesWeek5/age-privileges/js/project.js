//Create two variables for age and message

//Bind an onchange event to the #age input

	//Get the value of #age

	//Check if the person is 35 - Can run for president.
	//Check if the person is 25 - Can run for Senate and rent a car.
	//Check if the person is 21 - Can drink alcohol.
	//Check if the person is 19 - Can drink alcohol in Canada.
	//Check if the person is 18 - Can vote.

//Write a paragraph on the page with their privilege, based on their age.