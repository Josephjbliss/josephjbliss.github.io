$(document).ready(function() {

  setUp();

  $("body").mouseenter(function() {
    $("h1").fadeOut(500);
  });

  //Audio will go here



  //Pacman animations
  $("body").click(function(evt) {
    evt.preventDefault();
    var character = $("<img/>").attr("src", "img/ghost"+(Math.floor(Math.random(1)*10)%4+1)+".png").addClass("character").css("top", Math.floor(Math.random(1)*100)+"%");
    character.appendTo("body").animate({ left: "100%" }, 3000, "easeInOutBack", function() {
      $(this).remove();
    });
  });

});

function setUp() {
  $("body, html").height($(window).height());
  $("body, html").width($(window).width());
}

$(window).resize(function() {
  setUp();
});