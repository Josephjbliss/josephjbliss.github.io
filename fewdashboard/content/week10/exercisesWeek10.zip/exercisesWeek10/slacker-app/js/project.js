$("#status").change(function() {
  var status = $("#status").val();
  $("<div/>")
    .addClass("message")
    .append($("<img/>").attr("src", "img/avatar.png").addClass("avatar"))
    .append($("<p/>").html(status))
    .appendTo(".messages");
});