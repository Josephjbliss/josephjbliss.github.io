$(document).ready(function() {

  setUp();

  $("body").mouseenter(function() {
    $("h1").fadeOut(500);
  });

  //Audio will go here
  $("#volume").on("click", function(evt){
    evt.stopPropagation(); // Fire event on only this object, not on its parents
    $(this).toggleClass("fa-volume-up");
    $(this).toggleClass("fa-volume-off");

    if($(this).hasClass("fa-volume-off")) {
      // $("#audio")[0].pause(); // jQuery version returns an array []
      document.getElementById("audio").pause();      
    } 
    else {
      document.getElementById("audio").play();            
    }
  });

  //Pacman animations
  $("body").on("click", function(evt) {
    evt.preventDefault();
    var character = $("<img/>").attr("src", "img/ghost"+(Math.floor(Math.random(1)*10)%4+1)+".png").addClass("character").css("top", Math.floor(Math.random(1)*100)+"%");
    character.appendTo("body").animate({ left: "100%" }, 3000, "easeInOutBack", function() {
      $(this).remove();
    });
  });

});

function setUp() {
  $("body, html").height($(window).height());
  $("body, html").width($(window).width());
}

$(window).resize(function() {
  setUp();
});