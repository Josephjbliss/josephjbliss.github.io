$(".gallery").masonry({
  itemSelector: ".grid-item",
  columnWidth: ".thumbnail",
  percentPosition: true
});