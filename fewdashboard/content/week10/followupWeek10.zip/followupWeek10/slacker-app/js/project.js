$("#status").change(function() {
  var status = $("#status").val();
  
  $("#status").val("");
  
  if (status.substr(0, 6) === "/giphy") {
    mySearchTerm = status.substr(7);
    $.getJSON("http://api.giphy.com/v1/gifs/search?q=" + mySearchTerm + "&api_key=dc6zaTOxFJmzC", function(response) {
      // console.log(response);

      var randomNumber = Math.floor(Math.random() * 25);

      var myGifUrl = response.data[randomNumber].images.downsized_medium.url;
      // console.log(myGifUrl);

      $("<div/>")
      .addClass("message")
      .append($("<img/>").attr("src", myGifUrl).addClass("gif"))
      .appendTo(".messages");

    }); 
  }
  else {
    $("<div/>")
      .addClass("message")
      .append($("<img/>").attr("src", "img/avatar.png").addClass("avatar"))
      .append($("<p/>").html(status))
      .appendTo(".messages");
  }

});