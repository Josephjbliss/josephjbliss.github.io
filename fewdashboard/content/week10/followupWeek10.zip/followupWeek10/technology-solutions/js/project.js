document.getElementById("play").onclick = playVideo;
document.getElementById("pause").onclick = pauseVideo;

function playVideo() {
  document.getElementById("video").play();
}

function pauseVideo() {
  document.getElementById("video").pause();
}

$("#volume").on("click", function(evt){
  evt.stopPropagation(); // Fire event on only this object, not on its parents
  $(this).toggleClass("fa-volume-up");
  $(this).toggleClass("fa-volume-off");

  if($(this).hasClass("fa-volume-off")) {
    document.getElementById("video").volume = 0; 
  } 
  else {
    document.getElementById("video").volume = 1;
  }
});
