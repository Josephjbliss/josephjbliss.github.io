//05262ab637985a673278caf6e78624c4

$("#city").on("change", function() { 
  var url = "http://api.openweathermap.org/data/2.5/weather?q=" + $("#city").val() + "&APPID=05262ab637985a673278caf6e78624c4";

  $.getJSON(url, function(data){ 
    // console.log(data);
      var weatherString = "There is a high today of " + 
        Math.floor(data.main.temp_max * 9 / 5 - 456.67) + "&deg;" 
        + " in " + data.name 
        + " with " + data.weather[0].description;
    $("#weather").html(weatherString);
  });
});