$(document).ready(function() {
  $("nav a").on("click", function() {
    $("nav a").removeClass("current");
    $(this).addClass("current");
  });

  $("#submit").on("click", function() {
    var selector = "#" + $("nav a.current").data("ipsum");
    var numParagraphs = $("#paragraphs").val();
    $(".ipsum").hide();
    $(selector)
      .find("p")
      .slice(0, numParagraphs)
      .show();
    $(selector).slideDown(400);
  });

  $("#paragraphs").on("focus", function() {
    $("#paragraphs").val("");
    $(".ipsum").slideUp(1000, function() {
      $("p").hide();
    });
  });
});