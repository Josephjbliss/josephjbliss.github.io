$("body").mouseenter(function() {
  $("h1").fadeOut(500);
});

//Pacman animations will go here