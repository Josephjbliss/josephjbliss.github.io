$("body").mouseenter(function() {
  $("h1").fadeOut(500);
});

//Pacman animations will go here

$("body").on("click", function(evt){
  var pacman = $("<img/>");
  pacman.attr("src", "img/pacman.png");
  pacman.css("left", evt.pageX);
  pacman.css("top", evt.pageY);
  $("body").append(pacman);
  pacman.animate({ "left": "100%" }, 2000);

  var ghost1 = $("<img/>");
  ghost1.attr("src", "img/ghost1.png");
  ghost1.css("left", "-100px");
  ghost1.css("top", "0");
  $("body").append(ghost1);
  ghost1.delay(2000).animate({ "top": "50%", "left": "50%" }, 2000);
});