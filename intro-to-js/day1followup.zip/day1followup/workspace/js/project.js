document.getElementById('mobile').onclick = function(){
  document.getElementsByTagName('nav')[0].classList.toggle('open');
};

function showOverlay(){ 
  document.getElementById('overlay-wrapper').style.display = 'block';
}

function hideOverlay() {
  document.getElementById('overlay-wrapper').style.display = 'none';    

  // Check that input isn't empty
  // if (document.getElementById('email').value != '') {
    // document.getElementById('overlay-wrapper').style.display = 'none';    
  // }
}

document.getElementById('overlay-close').onclick = hideOverlay;

//show overlay on mouse entering body
// document.body.onmouseenter = showOverlay;

//show overlay after 5000 milliseconds
setTimeout(showOverlay, 5000);
