$(document).ready(function() {
  $("#clickme").click(addItem);

  $("#item").keypress(function(evt) {
    if (evt.which == 13) {
      addItem();
    }
  });

  function addItem() {
    if ($("#item").val() != "") {
      var newListItem = $("<li/>").html($("#item").val() );
      
      newListItem.on('click', function(){
        $(this).remove();
      });

      $("ul").append(newListItem);
      $("#item").val("");
    }
  }
});
