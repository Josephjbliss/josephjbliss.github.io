$(document).ready(function(){
  $(".thumb").click(function(){
    var clickedImage = $(this).attr("src");
    $("#bigimage").fadeOut(500, function(){
      $("#bigimage").attr("src", clickedImage);
      $("#bigimage").fadeIn(500);
    });
  });
});
