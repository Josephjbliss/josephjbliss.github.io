$(document).ready(function(){
	$("header").click(function(){
		if(!$(this).hasClass("open")) {			
			$(".wrapper").slideUp(500);
			$(this).addClass("open");
			$(this).next().slideToggle(500);		
		}
		else {
			$(".open").next().slideUp(500);
			$(".open").removeClass("open");
		}
	});
});