var myVideo = document.getElementById('background');

document.getElementById('play').onclick = playVideo;

function playVideo() {
  myVideo.play();
}

document.getElementById('pause').onclick = pauseVideo;

function pauseVideo() {
  myVideo.pause();
}

document.getElementById('volume').onclick = adjustVolume;

function adjustVolume() {
  if(myVideo.muted) {
    myVideo.muted = false;
  }
  else {
    myVideo.muted = true;
  }
  document.getElementById('volume').classList.toggle('fa-volume-up');
  document.getElementById('volume').classList.toggle('fa-volume-off');
}

