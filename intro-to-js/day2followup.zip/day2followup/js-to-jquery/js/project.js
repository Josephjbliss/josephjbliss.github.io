$(document).ready(function() {
  $("nav a").click(function() {
    var myColor = $(this).data("color");
    console.log("Current color is:" + myColor);
    $("header").css("background-color", myColor);
    $("nav a").css("background-color", myColor);
    $("p").css("color", myColor);
  });
});
