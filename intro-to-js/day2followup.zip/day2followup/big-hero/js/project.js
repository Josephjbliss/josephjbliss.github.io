$(document).ready(function(){
  $("nav a").click(function(evt){
    evt.preventDefault();
    var scrollToWhat = $(this).attr("href");
    var scrollToPixels = $(scrollToWhat).offset().top - $("nav").height();
    $("body").animate({scrollTop: scrollToPixels}, 500);
  });
});
